public class PercolationStats {

	private double[] temp;

	public PercolationStats(int n, int trials) {
		// perform trials independent experiments on an n-by-n grid
		for (int index = 1; index <= trials; index++) {
			
		}
	}

	public double mean() {
		return 0;
		// sample mean of percolation threshold
	}

	public double stddev() {
		return 0;
		// sample standard deviation of percolation threshold
	}

	public double confidenceLo() {
		return 0;
		// low endpoint of 95% confidence interval
	}

	public double confidenceHi() {
		return 0; // high endpoint of 95% confidence interval

	}

	public static void main(String[] args) {

	}

}